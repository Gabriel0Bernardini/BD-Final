/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Teste_Profs;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class Teste_ProfsDAO {

    public Teste_ProfsDAO() {
    }
    
    public boolean inserirTeste_Professor(Model_Teste_Profs TP){
        
        
        try {
            String SQL="INSERT INTO gabriel_vaz.testes_profs(numero_teste, prof,pcr,febre,mascara ,data_teste) VALUES(?,?,?,?,?,?)";
            Connection minhaConexao = Conexao.getConexao();
                        
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,TP.getNumero_teste());
            comando.setInt(2,TP.getId_prof());
            comando.setString(3,TP.getPcr());
            comando.setString(4,TP.getFebre());
            comando.setString(5,TP.getMascara());
            comando.setString(6,TP.getData_teste());
            
            int retorno = comando.executeUpdate();
            
            
            if(retorno>0){
                 return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }
    
    private Model_Teste_Profs pegaDados(ResultSet resultado){
        
        try {
            Model_Teste_Profs atual = new Model_Teste_Profs();
            
            atual.setNumero_teste(resultado.getInt("numero_teste"));
            atual.setId_prof(resultado.getInt("prof"));
            atual.setPcr(resultado.getString("pcr"));
            atual.setFebre(resultado.getString("febre"));
            atual.setMascara(resultado.getString("mascara"));
            atual.setData_teste(resultado.getString("data_teste"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
                
    }
    
    public List<Model_Teste_Profs> listarTestesDosProfessores(){
        try {
            String SQL = "SELECT numero_teste, prof, pcr, febre, mascara, data_teste FROM gabriel_vaz.testes_profs ORDER BY numero_teste";
            List<Model_Teste_Profs> listaDeTestesDosProfs = new ArrayList<Model_Teste_Profs>();
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Teste_Profs atual = new Model_Teste_Profs();
                atual = this.pegaDados(resultado);
                listaDeTestesDosProfs.add(atual);
            }
            
            return listaDeTestesDosProfs;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }    
      
   public Model_Teste_Profs consultaTesteProfessores(String numero_teste){
       
        try {
            String SQL = "SELECT numero_teste, prof, pcr, febre, mascara, data_teste FROM gabriel_vaz.testes_profs WHERE numero_teste = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(numero_teste));
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Teste_Profs atual = new Model_Teste_Profs();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        return null;
       
   }
      
   
   public boolean atualizaDadosTesteProfessores(Model_Teste_Profs dados){
       
        try {
            String SQL="UPDATE gabriel_vaz.testes_profs SET  prof=?,pcr=?,febre=?,mascara=? ,data_teste=? WHERE numero_teste=?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getNumero_teste());
            comando.setInt(1,dados.getId_prof());
            comando.setString(2,dados.getPcr());
            comando.setString(3,dados.getFebre());
            comando.setString(4,dados.getMascara());
            comando.setString(5,dados.getData_teste());
            
            int retorno = comando.executeUpdate();
            
            
            if(retorno>0){
                return true;
            }} catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
   }
       
   public Model_Teste_Profs consulta(Model_Teste_Profs dados){
       
        try {
            String SQL = "SELECT numero_teste, prof, pcr, febre, mascara, data_teste FROM gabriel_vaz.testes_profs ";
            String filtro ="";
            Connection c = Conexao.getConexao();
            
            
            if(dados != null && dados.getNumero_teste()>0){
                filtro = "WHERE numero_teste = "+dados.getNumero_teste();
            }
            
            if(dados != null && dados.getId_prof()>0){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND prof = "+dados.getId_prof();
                }else{
                    filtro = "WHERE prof = "+dados.getId_prof();
                }  
            }
            
            if(dados != null && dados.getPcr()!=null && !dados.getPcr().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND pcr ilike '%"+dados.getPcr()+"%'";
                }else{
                    filtro = "WHERE pcr ilike '%"+dados.getPcr()+"%'";
                }
            }
            
            if(dados != null && dados.getFebre()!=null && !dados.getFebre().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND febre ilike '%"+dados.getFebre()+"%'";
                }else{
                    filtro = "WHERE febre ilike '%"+dados.getFebre()+"%'";
                }
            }
            
            if(dados != null && dados.getMascara()!=null && !dados.getMascara().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND mascara ilike '%"+dados.getMascara()+"%'";
                }else{
                    filtro = "WHERE mascara ilike '%"+dados.getMascara()+"%'";
                }
            }
            
            if(dados != null && dados.getData_teste()!=null && !dados.getData_teste().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND data_teste ilike '%"+dados.getData_teste()+"%'";
                }else{
                    filtro = "WHERE data_teste ilike '%"+dados.getData_teste()+"%'";
                }
            }
            
            
            PreparedStatement ps = c.prepareStatement(SQL+filtro);
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Teste_Profs atual = new Model_Teste_Profs();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_ProfsDAO.class.getName()).log(Level.SEVERE, null, ex);
        }return null;
   }
   
}
