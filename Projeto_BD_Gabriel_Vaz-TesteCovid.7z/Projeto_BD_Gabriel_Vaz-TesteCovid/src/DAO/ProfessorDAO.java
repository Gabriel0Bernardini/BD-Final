/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Professor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class ProfessorDAO {

    public ProfessorDAO() {
    }
    
    public boolean inserirProfessor(Model_Professor p){
        
    
        try {
            String SQL="INSERT INTO gabriel_vaz.professor(id_prof, nome_prof,email,telefone,instituto) VALUES(?,?,?,?,?)";
    
            Connection minhaConexao = Conexao.getConexao();
   
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,p.getId_prof());
            comando.setString(2,p.getNome_prof());
            comando.setString(3,p.getEmail());
            comando.setString(4,p.getTelefone());
            comando.setString(5,p.getInstituto());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Professor pegaDados(ResultSet resultado){
         
        try {
            Model_Professor atual = new Model_Professor();
            
            atual.setId_prof(resultado.getInt("id_prof"));
            atual.setNome_prof(resultado.getString("nome_prof"));
            atual.setEmail(resultado.getString("email"));
            atual.setTelefone(resultado.getString("telefone"));
            atual.setInstituto(resultado.getString("instituto"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Model_Professor> listarProfessoresCadastrados(){
        
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_prof, nome_prof, email, telefone, instituto FROM gabriel_vaz.professor ORDER BY id_prof";
            List<Model_Professor> listaDeProfs = new ArrayList<Model_Professor>();
            
            PreparedStatement ps = c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Professor atual = new Model_Professor();
                atual = this.pegaDados(resultado);
                listaDeProfs.add(atual);
            }
            
            return listaDeProfs;
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
            
    public Model_Professor consultaProfessores(String id_prof){
        
        try {
            String SQL = "SELECT id_prof, nome_prof, email, telefone, instituto FROM gabriel_vaz.professor WHERE id_prof = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_prof));
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Professor atual = new Model_Professor();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }        
   
    public boolean  atualizaDadosProfessor(Model_Professor dados){
        
        try {
            String SQL="UPDATE gabriel_vaz.professor SET nome_prof=?,email=?,telefone=?,instituto=? WHERE id_prof=?";
            
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(5,dados.getId_prof());
            comando.setString(1,dados.getNome_prof());
            comando.setString(2,dados.getEmail());
            comando.setString(3,dados.getTelefone());
            comando.setString(4,dados.getInstituto());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
                        }
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Model_Professor consulta(Model_Professor dados){
        
        try {
            String SQL = "SELECT id_prof, nome_prof, email, telefone, instituto FROM gabriel_vaz.professor ";
            String filtro="";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_prof()>0){
                filtro = "WHERE id_prof = "+dados.getId_prof();
            }
            
            if(dados != null && dados.getNome_prof()!=null && !dados.getNome_prof().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_prof ilike '%"+dados.getNome_prof()+"%'";
                }else{
                    filtro = "WHERE nome_prof ilike '%"+dados.getNome_prof()+"%'";
                }  
            }
            
                        
            if(dados != null && dados.getEmail()!=null && !dados.getEmail().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND email ilike '%"+dados.getEmail()+"%'";
                }else{
                    filtro = "WHERE email ilke '%"+dados.getEmail()+"%'";
                }
            }
            
            if(dados != null && dados.getTelefone()!=null && !dados.getTelefone().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND telefone ilike "+dados.getTelefone()+"'";
                }else{
                    filtro = "WHERE telefone ilike '"+dados.getTelefone()+"'";
                }
            }
            
            if(dados != null && dados.getInstituto()!=null && !dados.getInstituto().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND instituto ilike '%"+dados.getInstituto()+"%'";
                }else{
                    filtro = "WHERE instituto ilike '%"+dados.getInstituto()+"%'";
                }
            }
            
            
            PreparedStatement ps = c.prepareStatement(SQL+filtro);
            
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Professor atual = new Model_Professor();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(ProfessorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
