/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Teste_Alunos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class Teste_AlunosDAO {

    public Teste_AlunosDAO() {
    }
    
    public boolean inserirTeste_Aluno(Model_Teste_Alunos TA){
        
       
        
        try {
            String SQL="INSERT INTO gabriel_vaz.testes_alunos(numero_teste, aluno,pcr,febre,mascara ,data_teste) VALUES(?,?,?,?,?,?)";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,TA.getNumero_teste());
            comando.setInt(2,TA.getAluno());
            comando.setString(3,TA.getPcr());
            comando.setString(4,TA.getFebre());
            comando.setString(5,TA.getMascara());
            comando.setString(6,TA.getData_teste());
            
            int retorno = comando.executeUpdate();
            
                
            if (retorno>0){
                return true;
            }
                
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Teste_Alunos pegaDados(ResultSet resultado){
        
        try {
            Model_Teste_Alunos atual = new Model_Teste_Alunos();
            
            atual.setNumero_teste(resultado.getInt("numero_teste"));
            atual.setAluno(resultado.getInt("aluno"));
            atual.setPcr(resultado.getString("pcr"));
            atual.setFebre(resultado.getString("febre"));
            atual.setMascara(resultado.getString("mascara"));
            atual.setData_teste(resultado.getString("data_teste"));
            
            return atual;
           } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Model_Teste_Alunos> listarTestesDosAlunos(){
        
        try {
            String SQL = "SELECT numero_teste, aluno, pcr,febre,mascara,data_teste FROM gabriel_vaz.testes_alunos ORDER BY numero_teste";
            List<Model_Teste_Alunos> listaTestesDosAlunos = new ArrayList<Model_Teste_Alunos>();
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Teste_Alunos atual = new Model_Teste_Alunos();
                atual = this.pegaDados(resultado);
                listaTestesDosAlunos.add(atual);
                
            }
            return listaTestesDosAlunos;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
            
    public Model_Teste_Alunos constultaTesteAlunos(String numero_teste){
            
        try {
            String SQL = "SELECT numero_teste, aluno, pcr,febre,mascara,data_teste FROM gabriel_vaz.testes_alunos WHERE numero_teste=?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(numero_teste));
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Teste_Alunos atual = new Model_Teste_Alunos();
                atual = this.pegaDados(resultado);
                return atual;
                
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
    
    public boolean atualizaDadosTesteAlunos(Model_Teste_Alunos dados){
        
    
        try {
            String SQL="UPDATE gabriel_vaz.testes_alunos SET aluno=?,pcr=?,febre=?,mascara=?,data_teste=? WHERE numero_teste=?";
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getNumero_teste());
            comando.setInt(1,dados.getAluno());
            comando.setString(2,dados.getPcr());
            comando.setString(3,dados.getFebre());
            comando.setString(4,dados.getMascara());
            comando.setString(5,dados.getData_teste());
            
            int retorno = comando.executeUpdate();
            
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public Model_Teste_Alunos consulta(Model_Teste_Alunos dados){
        
        try {
            String SQL = "SELECT numero_teste, aluno, pcr,febre,mascara,data_teste FROM gabriel_vaz.testes_alunos ";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            
            if(dados != null && dados.getNumero_teste()>0){
                filtro = "WHERE numero_teste = "+dados.getNumero_teste();
            }
            
            if(dados != null && dados.getAluno()>0){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND aluno = "+dados.getAluno();
                }else{
                    filtro = "WHERE aluno = "+dados.getAluno();
                }  
            }
            
            if(dados != null && dados.getPcr()!=null && !dados.getPcr().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND pcr ilike '%"+dados.getPcr()+"%'";
                }else{
                    filtro = "WHERE pcr ilike '%"+dados.getPcr()+"%'";
                }
            }
            
            if(dados != null && dados.getFebre()!=null && !dados.getFebre().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND febre ilike '%"+dados.getFebre()+"%'";
                }else{
                    filtro = "WHERE febre ilike '%"+dados.getFebre()+"%'";
                }
            }
            
            if(dados != null && dados.getMascara()!=null && !dados.getMascara().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND mascara ilike '%"+dados.getMascara()+"%'";
                }else{
                    filtro = "WHERE mascara ilike '%"+dados.getMascara()+"%'";
                }
            }
            
            if(dados != null && dados.getData_teste()!=null && !dados.getData_teste().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND data_teste ilike '%"+dados.getData_teste()+"%'";
                }else{
                    filtro = "WHERE data_teste ilike '%"+dados.getData_teste()+"%'";
                }
            }
            
            
            PreparedStatement ps = c.prepareStatement(SQL+filtro);
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Teste_Alunos atual = new Model_Teste_Alunos();
                atual = this.pegaDados(resultado);
                return atual;
                
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(Teste_AlunosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
