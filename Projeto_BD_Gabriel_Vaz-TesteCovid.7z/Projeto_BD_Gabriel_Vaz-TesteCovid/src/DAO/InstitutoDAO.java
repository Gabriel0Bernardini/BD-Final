/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Instituto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author gabri
 */
public class InstitutoDAO {

    public InstitutoDAO() {
    }
    
    public boolean inserirInstituto(Model_Instituto i){
        
        
        try {
            String SQL = "INSERT INTO gabriel_vaz.instituto(id_instituto,cidade,estado,numero_alunos) VALUES(?,?,?,?)";
        
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,i.getId_instituto());
            comando.setString(2,i.getCidade());
            comando.setString(3,i.getEstado());
            comando.setInt(4,i.getNumero_alunos());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
   
    private Model_Instituto pegaDados(ResultSet resultado){
        try {
            Model_Instituto atual = new Model_Instituto();
            
            atual.setId_instituto(resultado.getInt("id_instituto"));
            atual.setCidade(resultado.getString("cidade"));
            atual.setEstado(resultado.getString("estado"));
            atual.setNumero_alunos(resultado.getInt("numero_alunos"));
            
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public List<Model_Instituto> listarInstitutosCadastrados(){
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_instituto, cidade, estado, numero_alunos FROM gabriel_vaz.instituto ORDER BY id_instituto";
            List<Model_Instituto> listaDeInstitutos = new ArrayList<Model_Instituto>();
            
            PreparedStatement ps = c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Instituto atual = new Model_Instituto();
                atual = this.pegaDados(resultado);
                listaDeInstitutos.add(atual);
            }
            
            return listaDeInstitutos;
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public Model_Instituto consultaInstitutos(String id_instituto){
        try {
            String SQL = "SELECT id_instituto, cidade, estado, numero_alunos FROM gabriel_vaz.instituto WHERE id_instituto = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_instituto));
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Instituto atual = new Model_Instituto();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    public boolean atualizaDadosInstituto(Model_Instituto dados){
        
        try {
            String SQL = "UPDATE gabriel_vaz.instituto SET cidade=?,estado=?,numero_alunos=? WHERE id_instituto = ?";
            
            Connection minhaConexao = Conexao.getConexao();
            
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(4,dados.getId_instituto());
            comando.setString(1,dados.getCidade());
            comando.setString(2,dados.getEstado());
            comando.setInt(3,dados.getNumero_alunos());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
               return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;    
        
    }
    
    public Model_Instituto consulta(Model_Instituto dados){
        
        try {
            String SQL = "SELECT id_instituto, cidade, estado, numero_alunos FROM gabriel_vaz.instituto ";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_instituto()>0){
                filtro = "WHERE id_instituto = "+dados.getId_instituto();
            }
            
            if(dados != null && dados.getCidade()!=null && !dados.getCidade().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND cidade ilike '%"+dados.getCidade()+"%'";
                }else{
                    filtro = "WHERE cidade ilike '%"+dados.getCidade()+"%'";
                }  
            }
            
            if(dados != null && dados.getEstado()!=null && !dados.getEstado().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND estado ilike '%"+dados.getEstado()+"'";
                }else{
                    filtro = "WHERE estado ilike '%"+dados.getEstado()+"%'";
                }
            }
            
             if(dados != null && dados.getNumero_alunos()>0){
                if(!filtro.equalsIgnoreCase("")){ 
                    filtro = "AND numero_alunos = "+dados.getNumero_alunos();
                }else{
                    filtro = "WHERE numero_alunos = "+dados.getNumero_alunos();
                }
            }
            
            
            
            PreparedStatement ps = c.prepareStatement(SQL + filtro);
            
            ResultSet resultado = ps.executeQuery();
            
            if(resultado.next()){
                Model_Instituto atual = new Model_Instituto();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(InstitutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;    
    }
        
}
