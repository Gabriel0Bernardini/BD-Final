/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Conexao.Conexao;
import Model.Model_Aluno;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



/**
 *
 * @author gabri
 */
public class AlunoDAO {

    public AlunoDAO() {
    }
    
    
    
    public boolean inserirAluno(Model_Aluno a){
        
        try {
            String SQL="INSERT INTO gabriel_vaz.aluno(id_aluno, nome_aluno,turma,email,telefone,instituto) VALUES(?,?,?,?,?,?)";
            Connection minhaConexao = Conexao.getConexao();
        
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(1,a.getId_aluno());
            comando.setString(2,a.getNome_aluno());
            comando.setString(3,a.getTurma());
            comando.setString(4,a.getEmail());
            comando.setString(5,a.getTelefone());
            comando.setString(6,a.getInstituto());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    private Model_Aluno pegaDados(ResultSet resultado){
        try {
            Model_Aluno atual = new Model_Aluno();
            
            atual.setId_aluno(resultado.getInt("id_aluno"));
            atual.setNome_aluno(resultado.getString("nome_aluno"));
            atual.setTurma(resultado.getString("turma"));
            atual.setEmail(resultado.getString("email"));
            atual.setTelefone(resultado.getString("telefone"));
            atual.setInstituto(resultado.getString("instituto"));
            
            return atual;
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
        
    public List<Model_Aluno> listarAlunosCadastrados(){
        try {
            Connection c = Conexao.getConexao();
            String SQL = "SELECT id_aluno, nome_aluno, turma, email, telefone, instituto FROM gabriel_vaz.aluno ORDER BY id_aluno";
            List<Model_Aluno> listaDeAlunos = new ArrayList<Model_Aluno>();
            
            PreparedStatement ps =c.prepareStatement(SQL);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                Model_Aluno atual = new Model_Aluno();
                atual = this.pegaDados(resultado);
                listaDeAlunos.add(atual);
            }
            
            return listaDeAlunos;
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }  
    
   public Model_Aluno consultaAlunos(String id_aluno){ 
       
        try {
            String SQL = "SELECT id_aluno, nome_aluno, turma, email, telefone, instituto FROM gabriel_vaz.aluno WHERE id_aluno = ?";
            Connection c = Conexao.getConexao();
            PreparedStatement ps =c.prepareStatement(SQL);
            ps.setInt(1, Integer.valueOf(id_aluno));
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Aluno atual = new Model_Aluno();
                atual = this.pegaDados(resultado);
                return atual;
            }
            
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
       
   }
       
   public boolean atualizaDadosAluno(Model_Aluno dados){
        try {
            String SQL="UPDATE gabriel_vaz.aluno SET nome_aluno=?,turma=?,email=?,telefone=?,instituto=? WHERE id_aluno = ?";
            Connection minhaConexao = Conexao.getConexao();
        
            PreparedStatement comando = minhaConexao.prepareStatement(SQL);
            
            comando.setInt(6,dados.getId_aluno());
            comando.setString(1,dados.getNome_aluno());
            comando.setString(2,dados.getTurma());
            comando.setString(3,dados.getEmail());
            comando.setString(4,dados.getTelefone());
            comando.setString(5,dados.getInstituto());
            
            int retorno = comando.executeUpdate();
            
            if (retorno>0){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       return false;

   }
           
   public Model_Aluno consulta(Model_Aluno dados ){
        try {
            String SQL = "SELECT id_aluno, nome_aluno, turma, email, telefone, instituto FROM gabriel_vaz.aluno ";
            String filtro = "";
            Connection c = Conexao.getConexao();
            
            if(dados != null && dados.getId_aluno()>0){
                filtro = "WHERE id_aluno = "+dados.getId_aluno();
            }
            
            if(dados != null && dados.getNome_aluno()!=null && !dados.getNome_aluno().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND nome_aluno ilike '%"+dados.getNome_aluno()+"%'";
                }else{
                    filtro = "WHERE nome_aluno ilike '%"+dados.getNome_aluno()+"%'";
                }  
            }
            
            if(dados != null && dados.getTurma()!=null && !dados.getTurma().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND turma ilike '%"+dados.getTurma()+"%'";
                }else{
                    filtro = "WHERE turma ilike '%"+dados.getTurma()+"%'";
                }
            }
            
            if(dados != null && dados.getEmail()!=null && !dados.getEmail().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND email ilike '%"+dados.getEmail()+"%'";
                }else{
                    filtro = "WHERE email ilike '%"+dados.getEmail()+"%'";
                }
            }
            
            if(dados != null && dados.getTelefone()!=null && !dados.getTelefone().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND telefone ilike '"+dados.getTelefone()+"'";
                }else{
                    filtro = "WHERE telefone ilike '"+dados.getTelefone()+"'";
                }
            }
            
            if(dados != null && dados.getInstituto()!=null && !dados.getInstituto().equalsIgnoreCase("")){
                if(!filtro.equalsIgnoreCase("")){
                    filtro += "AND instituto ilike '%"+dados.getInstituto()+"%'";
                }else{
                    filtro = "WHERE instituto ilike '%"+dados.getInstituto()+"%'";
                }
            }
            
            PreparedStatement ps =c.prepareStatement(SQL + filtro);
            ResultSet resultado = ps.executeQuery();
            
            if (resultado.next()){
                Model_Aluno atual = new Model_Aluno();
                atual = this.pegaDados(resultado);
                return atual;
            }
            return null;
        } catch (SQLException ex) {
            Logger.getLogger(AlunoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
   } 
}
