/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Teste_Alunos {
    private int numero_teste,aluno;
    private String pcr, febre,mascara,data_teste;

    public Model_Teste_Alunos(int numero_teste, int aluno, String pcr, String febre, String mascara, String data_teste) {
        this.numero_teste = numero_teste;
        this.aluno = aluno;
        this.pcr = pcr;
        this.febre = febre;
        this.mascara = mascara;
        this.data_teste = data_teste;
    }

    public Model_Teste_Alunos() {
        this.numero_teste = 0;
        this.aluno = 0;
        this.pcr = "";
        this.febre = "";
        this.mascara = "";
        this.data_teste = "";
    }
    
    
    
    
    public int getNumero_teste() {
        return numero_teste;
    }

    public void setNumero_teste(int numero_teste) {
        this.numero_teste = numero_teste;
    }

    public int getAluno() {
        return aluno;
    }

    public void setAluno(int id_aluno) {
        this.aluno = id_aluno;
    }

    public String getPcr() {
        return pcr;
    }

    public void setPcr(String pcr) {
        this.pcr = pcr;
    }

    public String getFebre() {
        return febre;
    }

    public void setFebre(String febre) {
        this.febre = febre;
    }

    public String getMascara() {
        return mascara;
    }

    public void setMascara(String mascara) {
        this.mascara = mascara;
    }

    public String getData_teste() {
        return data_teste;
    }

    public void setData_teste(String data_teste) {
        this.data_teste = data_teste;
    }

    @Override
    public String toString() {
        return  numero_teste + "| ID do aluno: " + aluno + "| PCR: " + pcr + "| Febre: " + febre + "| Mascara: " + mascara + "| Data e Hora:" + data_teste;
    }

    
    
    
}
