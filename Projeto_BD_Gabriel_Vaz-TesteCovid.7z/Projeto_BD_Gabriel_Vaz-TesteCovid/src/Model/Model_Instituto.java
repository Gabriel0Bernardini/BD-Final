/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Instituto {
    private int id_instituto, numero_alunos;
    private String cidade,estado;

    public Model_Instituto(int id_instituto, int numero_alunos, String cidade, String estado) {
        this.id_instituto = id_instituto;
        this.numero_alunos = numero_alunos;
        this.cidade = cidade;
        this.estado = estado;
    }

    public Model_Instituto() {
        this.id_instituto = 0;
        this.numero_alunos = 0;
        this.cidade = "";
        this.estado = "";
    }

    
    
    
    public int getId_instituto() {
        return id_instituto;
    }

    public void setId_instituto(int id_instituto) {
        this.id_instituto = id_instituto;
    }

    public int getNumero_alunos() {
        return numero_alunos;
    }

    public void setNumero_alunos(int numero_alunos) {
        this.numero_alunos = numero_alunos;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return  id_instituto + " | " + numero_alunos + " alunos | " + cidade + " | " + estado;
    }
    
    
    
}
