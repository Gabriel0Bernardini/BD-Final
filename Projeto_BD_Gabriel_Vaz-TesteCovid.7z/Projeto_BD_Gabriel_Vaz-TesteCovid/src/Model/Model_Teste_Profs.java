/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Teste_Profs {
    private int numero_teste, id_prof;
    private String pcr,febre,mascara,data_teste;

    public Model_Teste_Profs(int numero_teste, int id_prof, String pcr, String febre, String mascara, String data_teste) {
        this.numero_teste = numero_teste;
        this.id_prof = id_prof;
        this.pcr = pcr;
        this.febre = febre;
        this.mascara = mascara;
        this.data_teste = data_teste;
    }

    public Model_Teste_Profs() {
        this.numero_teste = 0;
        this.id_prof = 0;
        this.pcr = "";
        this.febre = "";
        this.mascara = "";
        this.data_teste = "";
    }
    
    
    
    
    
    public int getNumero_teste() {
        return numero_teste;
    }

    public void setNumero_teste(int numero_teste) {
        this.numero_teste = numero_teste;
    }

    public int getId_prof() {
        return id_prof;
    }

    public void setId_prof(int id_prof) {
        this.id_prof = id_prof;
    }

    public String getPcr() {
        return pcr;
    }

    public void setPcr(String pcr) {
        this.pcr = pcr;
    }

    public String getFebre() {
        return febre;
    }

    public void setFebre(String febre) {
        this.febre = febre;
    }

    public String getMascara() {
        return mascara;
    }

    public void setMascara(String mascara) {
        this.mascara = mascara;
    }

    public String getData_teste() {
        return data_teste;
    }

    public void setData_teste(String data_teste) {
        this.data_teste = data_teste;
    }

    @Override
    public String toString() {
        return numero_teste + "| ID do Prof.:" + id_prof + "| PCR: " + pcr + "| Febre: " + febre + "| Mascara: " + mascara + "| Data e Hora: " + data_teste;
    }
    
    
    
}
