/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Professor {
   private int id_prof;
   private String nome_prof, email, telefone, instituto;

    public Model_Professor(int id_prof, String nome_prof, String email, String telefone, String instituto) {
        this.id_prof = id_prof;
        this.nome_prof = nome_prof;
        this.email = email;
        this.telefone = telefone;
        this.instituto = instituto;
    }

    public Model_Professor() {
        this.id_prof = 0;
        this.nome_prof = "";
        this.email = "";
        this.telefone = "";
        this.instituto = "";
    }

   
   
   
   
    public int getId_prof() {
        return id_prof;
    }

    public void setId_prof(int id_prof) {
        this.id_prof = id_prof;
    }

    public String getNome_prof() {
        return nome_prof;
    }

    public void setNome_prof(String nome_prof) {
        this.nome_prof = nome_prof;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getInstituto() {
        return instituto;
    }

    public void setInstituto(String instituto) {
        this.instituto = instituto;
    }

    @Override
    public String toString() {
        return id_prof + " | " + nome_prof + " | " + email + " | " + telefone + " | " + instituto;
    }
   
    
    
   
}
