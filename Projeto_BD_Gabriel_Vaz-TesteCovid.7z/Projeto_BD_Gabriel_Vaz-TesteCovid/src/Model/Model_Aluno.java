/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author gabri
 */
public class Model_Aluno {
    private int id_aluno;
    private String nome_aluno, turma, email,telefone, instituto;    
    
    
     public Model_Aluno(int id_aluno, String nome_aluno, String turma, String email, String telefone, String instituto) {
        this.id_aluno = id_aluno;
        this.nome_aluno = nome_aluno;
        this.turma = turma;
        this.email = email;
        this.telefone = telefone;
        this.instituto = instituto;
    }

    public Model_Aluno() {
        this.id_aluno = 0;
        this.nome_aluno = "";
        this.turma = "";
        this.email = "";
        this.telefone = "";
        this.instituto = "";
    }

    
    

    public int getId_aluno() {
        return id_aluno;
    }

    public void setId_aluno(int id_aluno) {
        this.id_aluno = id_aluno;
    }

    public String getNome_aluno() {
        return nome_aluno;
    }

    public void setNome_aluno(String nome_aluno) {
        this.nome_aluno = nome_aluno;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getInstituto() {
        return instituto;
    }

    public void setInstituto(String instituto) {
        this.instituto = instituto;
    }

    @Override
    public String toString() {
        return id_aluno + " | " + nome_aluno + " | " + turma + " | " + email + " | " + telefone + " | " + instituto;
    }

   
 
}
