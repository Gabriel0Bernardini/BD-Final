/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gabri
 */
public class Conexao {
    private static String url = "jdbc:postgresql://200.18.128.54/aula";
    private static String usuario = "aula";
    private static String senha = "aula";
    
    private static Connection minhaConexao=null;
    
    public static Connection getConexao(){
        try {
        if(Conexao.minhaConexao ==null){
            
            
                Conexao.minhaConexao = DriverManager.getConnection(url,usuario,senha);
            
        }
        
        return minhaConexao;
        } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Erro de conexão ao banco de dados: "+ex.getMessage());
        }
        return null;
    }
}
